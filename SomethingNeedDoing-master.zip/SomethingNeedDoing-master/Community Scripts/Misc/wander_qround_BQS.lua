i_see_perverts = 1

while i_see_perverts == 1 do
	yield("/vnav moveto 37.080055236816 8.0045347213745 -107.40134429932")
	yield("/wait 60")
	yield("/vnav moveto 45.156650543213 7.9999713897705 -96.050872802734")
	yield("/wait 60")
	yield("/vnav moveto 33.730579376221 6.9999990463257 -86.832260131836")
	yield("/wait 60")
	yield("/vnav moveto 33.730579376221 6.9999990463257 -86.832260131836")
	yield("/wait 60")
	yield("/vnav moveto 27.220218658447 7.9999828338623 -111.98528289795")
	yield("/wait 60")
	yield("/vnav moveto 38.206066131592 8.0051670074463 -106.16372680664")
	yield("/wait 60")
end