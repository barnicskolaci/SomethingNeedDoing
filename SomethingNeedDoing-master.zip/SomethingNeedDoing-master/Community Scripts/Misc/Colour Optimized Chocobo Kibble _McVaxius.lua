--[[
Colour Optimized Chocobo Kibble (C.O.C.K.)


Hackalicious way to do chocobo colouring

it will just tell you next thing to do 
--]]
