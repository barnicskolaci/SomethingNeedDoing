/freecompanycmd <wait.5>
/loop