yield("/p <se.5> Please be aware that I am about to use one of my core class abilities, which is called Ley Lines.")
yield("/ac Ley Lines <me>")
yield("/p I am placing the Ley Lines NOW. <wait.1>")
yield("/p When I use Ley Lines it places a CIRCLE on the GROUND that lasts for THIRTY SECONDS. <se.1> <wait.1>")
yield("/p If I remain in the circle, my Global Cooldown will be accelerated by FIFTEEN (15) PERCENT (%). <wait.1>")
yield("/p It is BENEFICIAL FOR THE GROUP if I am ALLOWED to REMAIN inside the Ley Lines. <wait.1>")
yield("/p Please let me do my own thing and do not place area of effect attacks inside the Ley Lines. <wait.13>")
yield("/p There are THIRTEEN SECONDS left in my Ley Lines. <se.1> <wait.5>")
yield("/p There are EIGHT SECONDS left in my Ley Lines. <se.6> <wait.7>")
yield("/p THERE IS ONE SECOND LEFT IN MY LEY LINES. <se.1> <wait.1>")
yield("/p <se.6> The Ley Lines have faded. Thank you for your cooperation. I will be doing this again in NINETY SECONDS. <se.6>")


--stolen from discord and reddit multiple sources
--[[
/p <se.5> Please be aware that I am about to use one of my core class abilities, which is called Ley Lines.
/micon "Ley Lines"
/ac "Ley Lines" <me>
/p I am placing the Ley Lines NOW. <wait.1>
/p When I use Ley Lines it places a CIRCLE on the GROUND that lasts for THIRTY SECONDS. <se.1> <wait.1>
/p If I remain in the circle, my Global Cooldown will be accelerated by FIFTEEN (15) PERCENT (%). <wait.1>
/p It is BENEFICIAL FOR THE GROUP if I am ALLOWED to REMAIN inside the Ley Lines. <wait.1>
/p Please let me do my own thing and do not place area of effect attacks inside the Ley Lines. <wait.13>
/p There are THIRTEEN SECONDS left in my Ley Lines. <se.1> <wait.5>
/p There are EIGHT SECONDS left in my Ley Lines. <se.6> <wait.7>
/p THERE IS ONE SECOND LEFT IN MY LEY LINES. <se.1> <wait.1>
/p <se.6> The Ley Lines have faded. Thank you for your cooperation. I will be doing this again in NINETY SECONDS. <se.6>
]]