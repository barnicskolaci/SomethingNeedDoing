﻿namespace SomethingNeedDoing.Macros.Commands.Modifiers;

/// <summary>
/// Base class for modifiers.
/// </summary>
internal abstract class MacroModifier
{
}
